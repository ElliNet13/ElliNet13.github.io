# ElliNet13's Library
Stuff: Bytes