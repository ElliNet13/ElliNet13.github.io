from setuptools import setup, find_packages

setup(
    name='ellinet13s_lib',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        "time"
        "struct"
    ],
)
